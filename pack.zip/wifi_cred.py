ssid =""
passwd =""